package com.example.test_step;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import java.util.ArrayList;

public class WebviewInterface {

    private Activity mContext;
    private WebView mWebView;
    private ArrayList<Integer> send;

    WebviewInterface(Activity act, WebView wv, ArrayList<Integer> target) {
        mContext = act;
        mWebView = wv;
        send = target;
    }

    @JavascriptInterface
    public int[] getArray() {
        int test[] = new int [send.size()];
        for (int i = 0; i < send.size(); i++) {
            test[i] = send.get(i);
        }
        return test;
    }
}
