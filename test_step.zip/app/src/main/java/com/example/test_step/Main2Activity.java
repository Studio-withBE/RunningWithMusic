package com.example.test_step;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {

    WebView web;
    String URL = "file:///android_asset/index.html";
    private ArrayList<Integer> tmp;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();

        web = (WebView)findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(true);

        ImageView running = (ImageView)findViewById(R.id.running);
        GlideDrawableImageViewTarget gifimage = new GlideDrawableImageViewTarget(running);
        Glide.with(this).load(R.drawable.run).into(gifimage);

        Bundle b = getIntent().getExtras();
        tmp = b.getIntegerArrayList("array");
/*
        WebviewInterface test = new WebviewInterface(Main2Activity.this, web, tmp);
        web.addJavascriptInterface(test, "Android");*/
        WebView.setWebContentsDebuggingEnabled(true);

        web.loadUrl(URL);
        web.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView view, String url) {
                String container = "";
                for (int i = 0; i < tmp.size(); i++) {
                    container += (tmp.get(i).toString() + " ");
                }
                web.loadUrl("javascript:myJavaScriptFunc('" + container + "')");
            }
        });
    }

}
